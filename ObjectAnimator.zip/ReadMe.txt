Installation instructions

To install and use the software:

1. Move the .jar file to somewhere that is memorable
2. The system is now useable by double-clicking the icon for the .jar file
3. To use this system, JAVA 1.8.0 must be installed.

Also, to see the source-code of this project, double click on the folder called Object Animator, 
and then double click on the folder called src. This will give you access to all of the source-code files
that were used in the creation of this project. 